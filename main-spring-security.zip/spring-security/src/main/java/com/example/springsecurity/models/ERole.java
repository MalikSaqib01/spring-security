package com.example.springsecurity.models;

public enum ERole {
    ROLE_USER,
    ROLE_PATHOLOGIST,
    ROLE_PHELEOBOTMIST,
    ROLE_PATIENT,
    ROLE_ADMIN
}
